// filepath: /hello-world-project/hello-world-project/src/hello_world.cpp
// Developer: [Your Name]
// Date: [Current Date]
// Purpose: This program prints "Hello, World!" to the console.

#include <iostream> // Include the iostream library for input and output
using namespace std; // Use the standard namespace

int main() {
    // Print "Hello, World!" to the console
    cout << "Hello, World!" << endl; // std::endl flushes the output buffer
    return 0; // Return 0 to indicate successful execution
}
